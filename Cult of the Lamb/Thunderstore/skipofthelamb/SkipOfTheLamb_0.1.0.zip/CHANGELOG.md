# Changelog

## v0.1.0
- Initial release
- Skip developer splash screens on game start
- Skip the crown video cutscene
