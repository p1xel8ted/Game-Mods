# Skip of the Lamb

A simple mod to skip splash screens and the crown video in Cult of the Lamb.

## Features

- **Skip Intros** - Skip the developer splash screens on game start
- **Skip Crown Video** - Skip the video when the lamb gets given the crown

## Configuration

All features are disabled by default. Use BepInEx Configuration Manager (F1) to enable them.
